#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(){
    int count=1;
    pid_t x,y,z,pid;
    x=fork();
    count++;
    y=fork();
    count++;
    z=fork();
    count++;
    pid=getpid();
    if(pid%2==1){
        if(fork()==0) 
        exit(0);
        count++;
    }
    sleep(1);
    if(getpid()>0) 
    printf("Porcesses created: %d\n",count);
    return 0;
}

