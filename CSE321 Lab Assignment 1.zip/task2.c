#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(){
    pid_t a,b;
    a=fork();
    if(a==0){
        b=fork();
        if(b==0){
            printf("I am grandchild\n");
            exit(0);}
        else if(b>0){
            wait(NULL);
            printf("I am child\n");
            exit(0);}
        else 
        exit(1);}
    else if(a>0){
        wait(NULL);
        printf("I am parent\n");}
    else 
    exit(1);}

