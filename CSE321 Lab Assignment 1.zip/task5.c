#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

int main(){
    pid_t x,y;
    x=fork();
    if(x==0){
        printf("Child process ID: %d\n",getpid());
        y=fork();
    if(y==0){ 
        printf("Grand Child process ID: %d\n",getpid()); 
        exit(0); }
    else if(y>0) 
        wait(NULL);
        y=fork();
    if(y==0){ 
        printf("Grand Child process ID: %d\n",getpid()); 
        exit(0); }
    else if(y>0) 
        wait(NULL);
        y=fork();
    if(y==0){ 
        printf("Grand Child process ID: %d\n",getpid()); 
        exit(0); }
    else if(y>0){ 
        wait(NULL); 
        exit(0); }
    else 
        exit(1);}
    else if(x>0){
        printf("Parent process ID: 0\n");
        wait(NULL);}
    else return 1;
    return 0;}

