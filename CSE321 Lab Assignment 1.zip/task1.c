#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char *argv[]){
    FILE *f=fopen(argv[f],"a");
    if{
        printf("File open error\n");
        return 0;
    }
    char s[1000];
    while(){
        printf("Input: ");
        fgets(s,sizeof(s),stdin);
        s[strcspn(s,"\n")]=0;
        if(strcmp(s,"-1")==0) 
        break;
        fprintf(f,"%s\n",s);}
    fclose(f);
    return 0;
}

