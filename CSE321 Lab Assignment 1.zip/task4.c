#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

void sort_desc(int arr[],int n){    //sorting.c
    int x,y,z;
    for(x=0;x<n-1;x++){
        for(y=x+1;y<n;y++){
            if(arr[x]<arr[y]){
                z=arr[x];
                arr[x]=arr[y];
                arr[y]=z;
            }
        }
    }
}

void check_oddeven(int arr[],int n){    //odd_even.c
    int x;
    for(x=0;x<n;x++){
        if(arr[x]%2==0) 
             printf("%d is even\n",arr[x]);
        else 
printf("%d is odd\n",arr[x]);
    }
}

int main(int argc,char *argv[]){  //parent child
    int n=argc-1;
    int arr[n],x;
    for(x=0;x<n;x++) arr[x]=atoi(argv[x+1]);
    pid_t c=fork();
    if(c==0){
        sort_desc(arr,n);
        printf("Array in descending:\n");
        for(x=0;x<n;x++) 
printf("%d ",arr[x]);
        printf("\n");
        exit(0);
    }
    else if(c>0){
        wait(NULL);
        check_oddeven(arr,n);
    }
    else return 1;
    return 0;
}

